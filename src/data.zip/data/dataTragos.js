export const dataShots =[
  { id: 1,
    name: 'Tequila Sunrise',
    value: '$24.000',
    value2: '',
    description: '6 tragos de tequila con jugo de naranja licor de durazno y granadina.'
  },
  {
    id: 1,
    name: 'Sex on the Beach',
    value: '$18.000',
    value2: '',
    description: '6 tragos de vodka con jugo de naranja licor de durazno y granadina.'
  },
  {
    id: 1,
    name: 'Bitch Mango',
    value: '$18.000',
    value2: '',
    description: '6 tragos con ginebra, vodka, limón y mango biche.'
  },
  {
    id: 1,
    name: 'Diablo Azul',
    value: '$22.000',
    value2: '',
    description: '6 tragos de vodka con ginebra y curazao azul.'
  },
  {
    id: 1,
    name: 'Cocaína rusa',
    value: '$20.000',
    value2: '',
    description: '6 tragos de vodka con limón, café y azúcar.'
  },
  {
    id: 1,
    name: 'Cocaína Kofla',
    value: '$22.000',
    value2: '',
    description: '6 tragos de vodka, ginebra con limón y sal.'
  },
  {
    id: 1,
    name: 'Lithium',
    value: '$24.000',
    value2: '',
    description: '6 tragos con tequila, whisky, ginebra y amaretto.'
  },
  {
    id: 1,
    name: 'Gin Pepper',
    value: '$22.000',
    value2: '',
    description: '6 tragos de vodka, ginebra con limón, pimienta y azúcar.'
  },
  {
    id: 1,
    name: 'Jaggeranja',
    value: '$36.000',
    value2: '',
    description: ''
  },
  {
    id: 1,
    name: 'Jagger',
    value: '$50.000',
    value2: '',
    description: ''
  },
  {
    id: 1,
    name: 'Jack Daniels',
    value: '$60.000',
    value2: '',
    description: ''
  },
  {
    id: 1,
    name: 'Jagger Bomb',
    value: '$36.000',
    value2: '',
    description: '6 tragos con Jager y energizante.'
  },
  {
    id: 1,
    name: 'Gin Tonic',
    value: '$26.000',
    value2: '',
    description: ''
  }
];
