export const dataSodas = [
  {
    id: 1,
    name: 'soda',
    value: '6.000',
    value2: '',
    value3: '',
    description: ''
  },
  {
    id: 2,
    name: 'Soda michelada',
    value: '7.000',
    value2: '',
    value3: '',
    description: 'soda con limon escarchada con sal.'
  },
  {
    id: 3,
    name: 'Soda saborizada',
    value: '8.000',
    value2: '',
    value3: '',
    description: 'soda con limon y sirope frutal escarchado con sal o azucar.'
  }
]