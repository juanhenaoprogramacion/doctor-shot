
export const dataShots =[
  {
    id: 1,
    name: 'Tequila sunrise',
    value: '26.000',
    value2: '8.000',
    value3: '',
    description: 'Tequila con zumo de naranja, licor de durazno y granadina.'
  },
  {
    id: 2,
    name: 'Sex on the beach',
    value: '22.000',
    value2: '7.000',
    value3: '',
    description: 'Vodka con zumo de naranja, licor de durazno y granadina.'
  },
  {
    id: 3,
    name: 'Bitch Mango',
    value: '25.000',
    value2: '8.000',
    value3: '',
    description: 'Ginebra, vodka, zumo de limón y mango biche.'
  },
  {
    id: 4,
    name: 'Diablo Azul',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, ginebra y curazao azul.'
  },
  {
    id: 5,
    name: 'Cocaina Rusa',
    value: '25.000',
    value2: '8.000',
    value3: '',
    description: 'Vodka, rodaja de limón con azúcar y café.'
  },
  {
    id: 6,
    name: 'Gin pepper',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, ginebra, rodaja de limón con pimienta y azúcar. '
  },
  {
    id: 7,
    name: 'Cocaina Kofla',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, ginebra, rodaja de limón con Sal.'
  },
  {
    id: 8,
    name: 'Lithium ',
    value: '27.000',
    value2: '10.000',
    value3: '',
    description: 'tequila, whisky, ginebra, ron y amareto.'
  },
  {
    id: 9,
    name: 'Ultravioleta',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, ginebra, curazao azul y granadina'
  },
  {
    id: 10,
    name: 'Tequila fuego',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Tequila, Tabasco, rodaja de limón con sal y escarchado de Tajín.'
  },
  {
    id: 11,
    name: 'Bombardero 52',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Crema de whisky, licor de café y ron'
  },
  {
    id: 12,
    name: 'Linterna verde',
    value: '40.000',
    value2: '20.000',
    value3: '',
    description: 'Absenta, ginebra y ron blanco'
  },
  {
    id: 13,
    name: 'Orgia frutal',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, granadina y frutas'
  },
  {
    id: 14,
    name: 'Bloody cream ',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Whisky, granadina y crema de whisky.'
  },
  {
    id: 15,
    name: 'Bloody Marie',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, zumo de tomate, limón, Tabasco y escarchado con sal.'
  },
  {
    id: 16,
    name: 'Bloody maría',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Tequila, zumo de tomate, limon Tabasco y escarchado con sal.'
  },
  {
    id: 17,
    name: 'Torito valiente',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Tequila, licor de café y gotas de picante.'
  },
  {
    id: 18,
    name: 'Gin toronja',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Ginebra, limón y gaseosa de toronja.'
  },
  {
    id: 19,
    name: 'gummy fun',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, curazao azul, gaseosa de limon y gomita.'
  },
  {
    id: 20,
    name: 'goma goma',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, ginebra, mango biche, gotas de limón y gomita.'
  },
  {
    id: 21,
    name: 'sexandia ',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Tequila, sandía, gotas de picante, escarchado de Tajín.'
  },
  {
    id: 22,
    name: 'Cuatro estaciones',
    value: '30.000',
    value2: '9.000',
    value3: '',
    description: 'Crema de whisky, curazao azul, granadina y vodka'
  },
  {
    id: 23,
    name: 'Cerebro',
    value: '25.000',
    value2: '9.000',
    value3: '',
    description: 'Vodka, granadina y crema de whisky.'
  },
  {
    id: 24,
    name: 'Río de lava (flameado)',
    value: '30.000',
    value2: '10.000',
    value3: '',
    description: 'Ron, ginebra, vodka, granadina y whisky'
  },
  {
    id: 25,
    name: 'demoledor',
    value: '45.000',
    value2: '20.000',
    value3: '',
    description: 'Absenta, Jager, Ginebra, ron blanco y vodka.'
  },
  {
    id: 26,
    name: 'Black demon',
    value: '35.000',
    value2: '18.000',
    value3: '',
    description: 'Heretic, wisky, ron.'
  },
  {
    id: 27,
    name: 'Gin tonic',
    value: '25.000',
    value2: '10.000',
    value3: '',
    description: 'Ginebra, agua tónica y zumo de limón.'
  },
  {
    id: 28,
    name: 'Jageranja',
    value: '38.000',
    value2: '18.000',
    value3: '',
    description: 'Jagger y zumo de Naranja.'
  },
  {
    id: 29,
    name: 'Jagger boom',
    value: '38.000',
    value2: '18.000',
    value3: '',
    description: 'Jagger y energizante.'
  },
  {
    id: 30,
    name: 'Jack and jagger',
    value: '60.000',
    value2: '25.000',
    value3: '',
    description: 'Jack daniels y jagger.'
  },
  {
    id: 31,
    name: 'Ron caldas',
    value: '',
    value2: '7.000',
    value3: '',
    description: ''
  },
  {
    id: 32,
    name: 'Ron medellin',
    value: '',
    value2: '7.000',
    value3: '',
    description: ''
  },
  {
    id: 33,
    name: 'Aguardiente antioqueño',
    value: '',
    value2: '7.000',
    value3: '',
    description: ''
  },
  {
    id: 34,
    name: 'Jack Daniels',
    value: '',
    value2: '15.000',
    value3: '',
    description: ''
  },
  {
    id: 35,
    name: 'Jagger',
    value: '',
    value2: '15.000',
    value3: '',
    description: ''
  },
  {
    id: 36,
    name: 'Tequila',
    value: '30.000',
    value2: '8.000',
    value3: '',
    description: ''
  },
  {
    id: 37,
    name: 'ginebra',
    value: '30.000',
    value2: '8.000',
    value3: '',
    description: ''
  },
  {
    id: 38,
    name: 'vodka',
    value: '30.000',
    value2: '8.000',
    value3: '',
    description: ''
  },
  {
    id: 39,
    name: 'Heretic',
    value: '',
    value2: '15.000',
    value3: '',
    description: ''
  },
  {
    id: 40,
    name: 'Absenta',
    value: '',
    value2: '20.000',
    value3: '',
    description: ''
  },

];