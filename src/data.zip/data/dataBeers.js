export const dataBeers =[
  {
    id: 1,
    name: 'Amarilla',
    value: '15.000',
    value2: '28.000',
    value3: '50.000',
    description: 'Cerveza, tequila, zumo de limón y zumo de naranja, escarchada con sal..'
  },
  {
    id: 2,
    name: 'Verde',
    value: '8.000',
    value2: '22.000',
    value3: '42.000',
    description: 'Cerveza, curasao azul y limón, escarchada con sal.'
  },
  {
    id: 3,
    name: 'Roja',
    value: '8.000',
    value2: '22.000',
    value3: '42.000',
    description: 'Cerveza, zumo de limón y granadina, escarchada con azúcar.'
  },
  {
    id: 4,
    name: 'Asesina',
    value: '15.000',
    value2: '28.000',
    value3: '50.000',
    description: 'Cerveza, vodka, ginebra, ron blanco y zumo de limón, escarchada con sal.'
  },
  {
    id: 5,
    name: 'Clorofila',
    value: '18.000',
    value2: '30.000',
    value3: '58.000',
    description: 'Ron blanco, azúcar, hierba buena y limon.'
  },
  {
    id: 6,
    name: 'Calaca',
    value: '15.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Cerveza, zumo de limón, picante, salsa inglesa, escarchado con Tajín.'
  },
  {
    id: 7,
    name: 'Michelada',
    value: '7.000',
    value2: '20.000',
    value3: '40.000',
    description: 'Cerveza, zumo de limón, escarchada con sal.'
  },
  {
    id: 8,
    name: 'Beer mango',
    value: '8.000',
    value2: '22.000',
    value3: '42.000',
    description: 'Cerveza, zumo de limón, mango biche, escarchada con sal o Tajín.'
  },
  {
    id: 9,
    name: 'Morgana',
    value: '15.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Cerveza, Ron, zumo de limón, almíbar y rodaja de limón.'
  },
  {
    id: 10,
    name: 'Mojito Beer',
    value: '18.000',
    value2: '30.000',
    value3: '50.000',
    description: 'Cerveza, hierva buena, zumo de limón y ron blanco.'
  }
];
