export const sectionCategories = [
  {
    id: 1,
    category: 'Shots'
  },
  {
    id: 2,
    category: 'Submarinos'
  },
  {
    id: 3,
    category: 'Cócteles'
  },
  {
    id: 4,
    category: 'Cervezas'
  },
  {
    id: 5,
    category: 'Sodas'
  }

]