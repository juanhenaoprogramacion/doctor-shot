export const dataSubmarinos =[
  {
    id: 1,
    name: 'Flaming Doctor pepper',
    value: '28.000',
    value2: '10.000',
    value3: '',
    description: 'Cerveza, copa de ron y amareto.'
  },
  {
    id: 2,
    name: 'submarino mexicano',
    value: '30.000',
    value2: '12.000',
    value3: '',
    description: 'Cerveza, copa de limón y tequila.'
  },
  {
    id: 3,
    name: 'Submarino Antioqueño',
    value: '28.000',
    value2: '10.000',
    value3: '',
    description: 'Cerveza, copa de aguardiente.'
  },
  {
    id: 4,
    name: 'Irish car boom',
    value: '46.000',
    value2: '16.000',
    value3: '',
    description: 'Cerveza negra, copa de crema de whisky y ron.'
  },
  {
    id: 5,
    name: 'jaggerboom',
    value: '46.000',
    value2: '16.000',
    value3: '',
    description: 'Energizante y jager.'
  },
  {
    id: 6,
    name: 'the revés jagerboom',
    value: '55.000',
    value2: '20.000',
    value3: '',
    description: 'Jager y energizante.'
  },
  {
    id: 7,
    name: 'Jack and boom',
    value: '46.000',
    value2: '16.000',
    value3: '',
    description: 'Energizante con Jack Daniels.'
  },
  {
    id: 8,
    name: 'Gin toronja',
    value: '30.000',
    value2: '12.000',
    value3: '',
    description: 'Gaseosa de toronja, como ginebra y limon.'
  }
];
