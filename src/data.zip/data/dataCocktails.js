
export const dataCocktails =[
  {
    id: 1,
    name: 'Tequila sunrise',
    value: '25.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Tequila, jugo de naranja, licor de durazno y granadina.'
  },
  {
    id: 2,
    name: 'Monstruo del pantano',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, mango biche, gaseosa de Limón y granadina.'
  },
  {
    id: 3,
    name: 'caipiroska',
    value: '28.000',
    value2: '40.000',
    value3: '75.000',
    description: 'Vodka, azúcar y limón.'
  },
  {
    id: 4,
    name: 'Margarita',
    value: '25.000',
    value2: '40.000',
    value3: '75.000',
    description: 'Tequila, limon, sal y triple sec.'
  },
  {
    id: 5,
    name: 'Mojito',
    value: '28.000',
    value2: '40.000',
    value3: '75.000',
    description: 'Ron blanco, azúcar, hierba buena y limon.'
  },
  {
    id: 6,
    name: 'Cuba libre',
    value: '25.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Ron, coca cola y limon.'
  },
  {
    id: 7,
    name: 'king of the road ',
    value: '30.000',
    value2: '58.000',
    value3: '110.000',
    description: 'Jack daniels, jagger, soda, limón.'
  },
  {
    id: 8,
    name: 'Black Dog',
    value: '28.000',
    value2: '',
    value3: '',
    description: 'Jager, crema de wisky.'
  },
  {
    id: 9,
    name: 'coffe Paradise',
    value: '30.000',
    value2: '',
    value3: '',
    description: 'Wisky, licor de café, amareto, crema de wisky.'
  },
  {
    id: 10,
    name: 'ack and jager',
    value: '30.000',
    value2: '60.000',
    value3: '115.000',
    description: 'Jack daniels, jager y energizante o soda.'
  },
  {
    id: 11,
    name: 'Bloody Mary',
    value: '25.000',
    value2: '',
    value3: '',
    description: 'Vodka, zumo de tomate, Tabasco, limon.'
  },
  {
    id: 12,
    name: 'Boody María',
    value: '28.000',
    value2: '',
    value3: '',
    description: 'Tequila, zumo de tomate, Tabasco, limon.'
  },
  {
    id: 13,
    name: 'Jagerboom',
    value: '30.000',
    value2: '55.000',
    value3: '110.000',
    description: 'Jager, energizante.'
  },
  {
    id: 14,
    name: 'ultravioleta ',
    value: '28.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Vodka, ginebra, curazao azul, granadina y gaseosa de limón .'
  },
  {
    id: 15,
    name: 'Laguna azul',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, limon, curazao azul.'
  },
  {
    id: 16,
    name: 'Bitch Mango',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, mango biche y limon.'
  },
  {
    id: 17,
    name: 'Red Machine',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, limon, granadina, gaseosa de limon.'
  },
  {
    id: 18,
    name: 'Gin tonic',
    value: '28.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Ginebra, agua tónica, limón.'
  },
  {
    id: 19,
    name: 'Sex on the beach',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, naranja, durazno y granadina.'
  },
  {
    id: 20,
    name: 'Gin toronja',
    value: '28.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Ginebra, limon, gaseosa de toronja.'
  },
  {
    id: 21,
    name: 'sexandia ',
    value: '25.000',
    value2: '38.000',
    value3: '70.000',
    description: 'Tequila, sandía, gotas de picante, gaseosa Limón,escarchado de Tajín.'
  },
  {
    id: 22,
    name: 'Jageranja',
    value: '30.000',
    value2: '55.000',
    value3: '110.000',
    description: 'Jager, naranja.'
  },
  {
    id: 23,
    name: 'Long island',
    value: '35.000',
    value2: '65.000',
    value3: '110.000',
    description: 'Tequila, ron, vodka, ginebra, zumo de Limón y coca cola .'
  },
  {
    id: 24,
    name: 'Poison Apple',
    value: '22.000',
    value2: '28.000',
    value3: '48.000',
    description: 'Vodka, manzana verde, Limón.'
  }
];